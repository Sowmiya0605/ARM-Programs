#include<lpc21xx.h>
#define led0 1<<0
#define led1 1<<1
#define EINT0_fn 1<<0
#define EINT1_fn 1<<29

/*External Interrupt0 ISR*/
void ext_int0_isr(void)__irq
{
	EXTINT=0x01;//clear EINT0 flag
	IOSET0=led0;
	IOCLR0=led0;
	VICVectAddr=0x00;	
	
}

/*External Interrupt1 ISR*/
void ext_int1_isr(void)__irq
{
	EXTINT=0x02;//to clear EINT1 flag
	IOSET0=led1;
	IOCLR0=led1;
	VICVectAddr=0x00;
	
}

int main()
{
	int cnt=0;
	PINSEL1=EINT0_fn;//P0.16 as EINT0 pin
	PINSEL0=EINT1_fn;//P0.14 as EINT1 pin
	IODIR0=led0|led1;//P0.0 , P0.1 selected as Output pins
	//Category of Interrupts
	VICIntSelect=0x00000000;
	
	//Allocate slot-0 for Ext Int0
	VICVectCntl0=(0x20)|14;
	VICVectAddr0=(int)ext_int0_isr;
	
	//Allocate slot-1 for Ext Int1
	VICVectCntl1=(0x20)|15;
	VICVectAddr1=(int)ext_int1_isr;
	
	//Mode selection
	EXTMODE=0x03;//edge senisitivity
	EXTPOLAR=0x00;//falling-edge
	
	//Enable the interrupt
	VICIntEnable=(1<<14)|(1<<15);
	while(1)
	{
		cnt++;
	}		
	
}

