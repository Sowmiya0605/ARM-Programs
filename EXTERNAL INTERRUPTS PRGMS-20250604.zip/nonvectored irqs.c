#include<lpc21xx.h>
#define led0 1<<0
#define led1 1<<1

void Non_Vect_ISR(void)__irq
{
	if(VICIRQStatus&(1<<14))
	{
		EXTINT=0x01;//To clear EINT0 flag
		IOSET0=led0;
		IOCLR0=led0;	
		
	}
	if(VICIRQStatus&(1<<15))
	{
		EXTINT=0x02;//To clear EINT1 flag
		IOSET0=led1;
		IOCLR0=led1;
		
	}
	VICVectAddr=0;//End of ISR
	
}

int main()
{
	int cnt=0;
	PINSEL1|=0x00000001;//P0.16 as EINT0
	PINSEL0|=0x20000000;//P0.14 as EINT1
	IODIR0=led0|led1;
	VICIntSelect=0;//All are IRQs
	VICDefVectAddr=(int)Non_Vect_ISR;
	
	EXTMODE=0x03;//edge
	EXTPOLAR=0x00;//Falling-edge
	
	VICIntEnable=(1<<14)|(1<<15);
	while(1)
	{
		cnt++;
	}
	
	
}