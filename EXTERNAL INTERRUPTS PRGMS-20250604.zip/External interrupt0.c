#include<lpc21xx.h>
#define led0 1<<0
#define EINT0_fn 1<<0

/*External Interrupt0 ISR*/
void ext_int0_isr(void)__irq
{
	EXTINT=0x01;//To clear EINT0 flag
	IOSET0=led0;
	IOCLR0=led0;
	VICVectAddr=0x00;//To indicate end of ISR
	
	
}



int main()
{
	int cnt=0;
	PINSEL1=EINT0_fn;//P0.16 configured as EINT0
	IODIR0=led0;
	
	/*Select the category of interrupt*/
	VICIntSelect=0x00000000;//All are IRQ's
	
	/*Allocate slot-0 to External Interrupt0*/
	VICVectCntl0=(0x20)|14;
	VICVectAddr0=(int)ext_int0_isr;
	
	/*Select the External Interrupt Mode*/
	EXTMODE=0x00;//level-sensitivity
	EXTPOLAR=0x00;//low-level sensitivity
	
	/*Enable the Interrupt*/
	VICIntEnable=1<<14;//External Interrupt0 Enabled
	
	/*main line code*/
	while(1)
	{
		cnt++;
	}		
	
	
}