#include<lpc21xx.h>
#define AL_Led1 1<<0
#define AL_Led2 1<<1

void delay_ms(int ms)
{
unsigned int i;
for(;ms>0;ms--)
for(i=12000;i>0;i--);	
	
}

int main()
{
	PINSEL0=0x00000000;//P0.0 to P0.15 as GPIO's
	IODIR0=AL_Led1|AL_Led2;//P0.0 and P0.1 pins selected as Output pins
	
	while(1)
	{
		IOCLR0=AL_Led1|AL_Led2;//Power-On AL Leds
		delay_ms(500);//delay of 500 milliseconds
		IOSET0=AL_Led1|AL_Led2;//Power-off AL leds
		delay_ms(500);//delay of 500 milliseconds
		
	}
	
}