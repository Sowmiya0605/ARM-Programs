#include<lpc21xx.h>
#define led1 1<<15

void delay_ms(int ms)
{
	unsigned int i;
	for(;ms>0;ms--)
	for(i=12000;i>0;i--);
	
}

int main()
{
	PINSEL0=0x00000000;//P0.0 to P0.15 as GPIO's
	//IODIR0=0x00008000;//P0.15 as Output pin
	
	IODIR0=led1;
	
	while(1)
	{
		/*IOCLR0=0x00008000;//Power-on AL Led
		delay_ms(500);
		IOSET0=0x00008000;//Power-off AL Led
		delay_ms(500);*/
		
		IOCLR0=led1;
		delay_ms(500);
		IOSET0=led1;
		delay_ms(500);
		
	}
		
}