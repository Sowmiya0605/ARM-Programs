#include<lpc21xx.h>
#define AH_Led1 1<<0
#define AH_Led2 1<<1

void delay_ms(int ms)
{
unsigned int i;
for(;ms>0;ms--)
for(i=12000;i>0;i--);	
	
}

int main()
{
	PINSEL0=0x00000000;//P0.0 to P0.15 as GPIO's
	IODIR0=AH_Led1|AH_Led2;//P0.0 and P0.1 pins selected as Output pins
	
	while(1)
	{
		IOSET0=AH_Led1|AH_Led2;//Power-On AH Leds
		delay_ms(500);//delay of 500 milliseconds
		IOCLR0=AH_Led1|AH_Led2;//Power-off AH leds
		delay_ms(500);//delay of 500 milliseconds
		
	}
	
}