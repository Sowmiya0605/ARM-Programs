#include<lpc21xx.h>

int main()
{
	PINSEL0=0x00000000;//P0.0 to P0.15 as GPIO's
	IODIR0=0x00000001;//P0.0 is selected as Output pin
	while(1)
	{
		IOCLR0=0x00000001;//Power-on AL Led
		IOSET0=0x00000001;//Power-off AH Led
		
	}
	
}