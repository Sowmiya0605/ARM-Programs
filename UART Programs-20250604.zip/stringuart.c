/*Write an ECP to transmit any string to hyperterminal
serially through UART0 of LPC2129*/
#include<lpc21xx.h>
#include"uartheader.h"

int main()
{
	UART0_CONFIG();
	UART0_STR("VECTOR INDIA");
	
}