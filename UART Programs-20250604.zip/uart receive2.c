/*Write an ECP to receive and re-tranmsit characters serially through
UART0 of LPC2129 MC*/
#include<lpc21xx.h>
#include"uartheader.h"


int main()
{
	unsigned char x;
	UART0_CONFIG();
	while(1)
	{
		x=UART0_RX();
		UART0_TX(x);
		
	}
	
}