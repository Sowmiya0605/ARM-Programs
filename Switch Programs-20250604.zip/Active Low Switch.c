#include<LPC21XX.h>

#define led0 1<<18
#define al_sw 1<<19

int main()
{
	IODIR1=led0;//P1.18 pin selected as Output pin and rest as input pins
		while(1)
	{
		if((IOPIN1&al_sw)==0)//Testing the pin status
		{
			IOCLR1=led0;//power-on AL Led
		}
		
		else
		{
			IOSET1=led0;//Power-off AL Led
		}
}

}