#include<lpc21xx.h>
#define led0 1<<17
#define led1 1<<18
#define sw0 1<<14
#define sw1 1<<15

int main()
{
	IODIR0=led0|led1;
	
	while(1)
	{
		if((IOPIN0&sw0)==0)
			IOSET0=led0;//Turn-on AH led
		else if((IOPIN0&sw1)==0)
			IOSET0=led1;//Turn-on AH Led
		else
		{
			IOCLR0=led0;//Turn-off AH led
			IOCLR0=led1;//Turn-off AH Led
		}
		
	}
	
}