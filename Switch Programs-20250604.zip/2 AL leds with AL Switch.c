#include<lpc21xx.h>
#define led0 1<<17
#define led1 1<<18

#define sw0 1<<14
#define sw1 1<<15

int main()
{
	IODIR0=led0|led1;
	
	while(1)
	{
		if((IOPIN0&sw0)==0)
			IOCLR0=led0;//Turn-on AL Led
		else if((IOPIN0&sw1)==0)
			IOCLR0=led1;//Turn-on AL Led
		else
		{
			IOSET0=led0;//Turn-off AL led
			IOSET0=led1;//Turn-off AL Led
		}
		
	}
	
}