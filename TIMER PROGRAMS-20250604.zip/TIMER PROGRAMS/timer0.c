#include<lpc21xx.h>
int main()
{
	T0PR=15000000-1;//Assign the Prescale value to Prescale register
	
	T0TCR=0x01;//Timer0 Start (T0PC and T0TC are enabled for counting)
	
	while(T0TC<1);//waiting for 1 second delay
	
	T0TCR=0x03;//Reset count registers
	
	T0TCR=0x00;//Timer0 stop
	
	
}